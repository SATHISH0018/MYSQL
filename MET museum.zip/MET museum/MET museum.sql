create database museum;

use museum;

create table met(
ID INT PRIMARY KEY,
Department varchar(100),
Category varchar(100),
Title varchar(100),
Artist varchar(100),
Date varchar(100),
Medium varchar(100),
Country varchar(100));

-- 1.Select the top 10 rows in the met table. 

select * from met
limit 10;

-- 2.How many pieces are in the American Metropolitan Art collection? [count(*)] 


select * from met;
select * from met 
where Department = 'American Metropolitan Art';

-- 3.Count the number of pieces where the category includes ‘celery’. 

select count(*)
from met 
where Category like '%Celery%';

-- 4.Find the title and medium of the oldest piece(s) in the collection
select Title,Medium from met 
order by date;

-- 5.Find the top 10 countries with the most pieces in the collection.

select Country
from met 
group by Country 
order by Country desc
limit 10;

-- 6.Find the categories which have more than 100 pieces. 

select category, count(*) as cnt
from met 
group by Category
having cnt > 100;

-- 7.Count the number of pieces where the medium contains ‘gold’ or ‘silver’ and sort in descending order. 

select count(*) as count_of_gold
from met 
where Medium = 'Gold';
