create database restaurant;

use restaurant;

create table orders(
ID INT,
User_id INT,
Order_date DATE,
Restaurant_id INT,
item_name varchar(100),
Special_instructions TEXT);

-- 1.Start by getting a feel for the orders table. Select the table and see the columns.

select * from orders;

-- 2.How recent is this data? 

select * from orders 
order by Order_date desc;

-- 3.The special_instructions column stores the data where customers leave a note for the kitchen or the delivery. How many customers doesn’t leave a note?

select count(*)
from orders 
where Special_instructions = 0;

-- 4.On sprecial_instructions column, remove the null values and sort them in alphabetical order (A-Z).
SELECT special_instructions
where special_instructions is not null
ORDER BY special_instructions ASC;

-- 5.Search for special instructions that have the word ‘sauce’ or ‘door’ in it.

select * from orders;

select Special_instructions
from orders 
where Special_instructions like '%sauce%';

-- 6.How many unique customers does this restaurant have? 

select distinct(User_id)
from orders;

-- 7.Top 3 most ordered dishes in the restaurant.
select item_name
from orders 
group by item_name
limit 3;
