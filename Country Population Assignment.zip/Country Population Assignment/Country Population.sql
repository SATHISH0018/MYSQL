create database country_population;

use country_population;

create table population(
Country varchar(100),
Population Double,
Year INT);

-- 1.What years are covered by the dataset? 

select * from population;

select distinct(Year)
from population;

-- 2.What is the largest population size for Gabon in this dataset?

select * from population;

select * from population
where Country = 'Gabon'
order by Country desc
limit 1;

-- 3.What were the 10 lowest population countries in 2005?

select *
from population
where year = 2005
order by Population 
limit 10;

-- 4.What are all the distinct countries with a population of over; 100 million in the year 2010?

select distinct(Country),Population
from population
where Year = 2010 and population > 100;

-- 5.How many countries in this dataset have the word “Islands” in their name?

select country 
from population
having country like '%Islands%';

-- 6.What is the difference in population between 2000 and 2010 in Indonesia?

select 
(select population
from population
where country = 'Indonesia' and year=2010) - (select population from population 
where country = 'Indonesia' and year=2000) as difference_population;