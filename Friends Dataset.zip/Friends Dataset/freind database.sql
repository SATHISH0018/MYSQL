create database friend;

use friend;

create table dosth(
ID int primary key,
Name varchar(20),
Birthday_date date);

-- 1.Add a record name john doe whose birthday 1996-08-30

insert into dosth(ID, Name, Birthday_date)
values
(1,'jhon doe', '1996-08-30');

-- 2.view the table using select

select * from dosth;

-- 3.Now add two of your friends you like.

insert into dosth(ID,Name,Birthday_date)
values
(2,'Sravan','2000-09-27'),
(3,'Mahesh','2002-08-23');

-- 4.change the name of the first friend called 'john doe' to 'Luis Johnson'

set sql_safe_updates = 0;

update dosth 
set Name = 'Luis johnson'
where Name = 'jhon doe';

-- 5.add a new column called email 

alter table dosth 
add column Email varchar(255);

-- 6.Update the email address for Luis in your table.
 -- Luis email is luis@gmail.com
 
 update dosth
 set Email = 'luis@gmail.com'
 where Name = 'Luis johnson';
 
 -- 7.remove Luis from friends 
 
 delete from dosth 
 where ID = 1;
 
 -- 8.view complete table using select
 
 select * from dosth;